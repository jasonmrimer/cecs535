CREATE VIEW flight_delays_time as 
select origin, dest, fl_num , (cast(strftime('%s',fl_date) as int) + crs_dep_time/100*3600+crs_dep_time%100*60) as dept_time, (cast(strftime('%s',fl_date) as int) + crs_arr_time/100*3600+crs_arr_time%100*60) as arr_time from flight_delays;

