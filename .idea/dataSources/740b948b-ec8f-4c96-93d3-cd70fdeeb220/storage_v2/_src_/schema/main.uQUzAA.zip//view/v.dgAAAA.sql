CREATE VIEW v (id,avg_arr_delay) as select airline_id,avg(arr_delay)from flight_delays;

