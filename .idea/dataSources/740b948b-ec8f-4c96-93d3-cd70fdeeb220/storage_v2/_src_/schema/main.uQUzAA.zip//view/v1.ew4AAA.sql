CREATE VIEW v1 (id,avg_arr_delay) as select airline_id,avg(arr_delay)from flight_delays group by airline_id;

